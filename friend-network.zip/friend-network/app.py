"""
Enhanced Friend Request Simulator System with Messaging
DSA Project - Namal University
Implements: Graphs, Hash Tables, Sets, Queues, Trees, Sorting Algorithms
New Features: Profile Pictures, Messaging (Text + Images), Enhanced UI, Profile Update
"""

from flask import Flask, render_template, request, jsonify, session, redirect, url_for, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import json
import os
import base64
from datetime import datetime
from collections import deque, defaultdict
import secrets
import uuid

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)

# Configure upload folders
UPLOAD_FOLDER = 'uploads'
PROFILE_PICS_FOLDER = os.path.join(UPLOAD_FOLDER, 'profile_pics')
MESSAGE_IMAGES_FOLDER = os.path.join(UPLOAD_FOLDER, 'message_images')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

# Create directories if they don't exist
os.makedirs(PROFILE_PICS_FOLDER, exist_ok=True)
os.makedirs(MESSAGE_IMAGES_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

class Message:
    """Message class for storing chat messages"""
    def __init__(self, sender, receiver, content, message_type='text', image_path=None):
        self.id = str(uuid.uuid4())
        self.sender = sender
        self.receiver = receiver
        self.content = content
        self.message_type = message_type  # 'text' or 'image'
        self.image_path = image_path
        self.timestamp = datetime.now().isoformat()
        self.read = False
    
    def to_dict(self):
        return {
            'id': self.id,
            'sender': self.sender,
            'receiver': self.receiver,
            'content': self.content,
            'message_type': self.message_type,
            'image_path': self.image_path,
            'timestamp': self.timestamp,
            'read': self.read
        }
    
    @staticmethod
    def from_dict(data):
        msg = Message(
            data['sender'],
            data['receiver'],
            data['content'],
            data.get('message_type', 'text'),
            data.get('image_path')
        )
        msg.id = data['id']
        msg.timestamp = data['timestamp']
        msg.read = data.get('read', False)
        return msg


class User:
    """Enhanced User Class with profile picture and messaging"""
    def __init__(self, username, password_hash, profile_pic=None):
        self.username = username
        self.password_hash = password_hash
        self.profile_pic = profile_pic or "default-avatar.png"
        self.created_at = datetime.now().isoformat()
        self.friends = set()
        self.pending_requests = []
        self.sent_requests = []
        self.bio = ""
        self.last_seen = datetime.now().isoformat()
    
    def to_dict(self):
        return {
            'username': self.username,
            'password_hash': self.password_hash,
            'profile_pic': self.profile_pic,
            'created_at': self.created_at,
            'friends': list(self.friends),
            'pending_requests': self.pending_requests,
            'sent_requests': self.sent_requests,
            'bio': self.bio,
            'last_seen': self.last_seen
        }
    
    @staticmethod
    def from_dict(data):
        user = User(data['username'], data['password_hash'], data.get('profile_pic'))
        user.created_at = data['created_at']
        user.friends = set(data['friends'])
        user.pending_requests = data['pending_requests']
        user.sent_requests = data['sent_requests']
        user.bio = data.get('bio', '')
        user.last_seen = data.get('last_seen', datetime.now().isoformat())
        return user


class SocialNetworkGraph:
    """Enhanced Graph with Messaging System"""
    def __init__(self):
        self.users = {}
        self.adjacency_list = defaultdict(set)
        self.messages = []  # List to store all messages
        self.message_index = defaultdict(list)  # Index messages by users for fast lookup
    
    def add_user(self, username, password, profile_pic=None):
        """Add new user with optional profile picture"""
        if username in self.users:
            return False, "Username already exists"
        
        password_hash = generate_password_hash(password)
        user = User(username, password_hash, profile_pic)
        self.users[username] = user
        self.adjacency_list[username] = set()
        self.save_data()
        return True, "User created successfully"
    
    def authenticate_user(self, username, password):
        """Verify user credentials"""
        if username not in self.users:
            return False
        return check_password_hash(self.users[username].password_hash, password)
    
    def update_last_seen(self, username):
        """Update user's last seen timestamp"""
        if username in self.users:
            self.users[username].last_seen = datetime.now().isoformat()
            self.save_data()
    
    def update_profile_picture(self, username, profile_pic):
        """Update user's profile picture"""
        if username in self.users:
            self.users[username].profile_pic = profile_pic
            self.save_data()
            return True, "Profile picture updated successfully"
        return False, "User not found"
    
    def send_friend_request(self, sender, receiver):
        """Send friend request"""
        if receiver not in self.users:
            return False, "User not found"
        
        if sender == receiver:
            return False, "Cannot send request to yourself"
        
        if receiver in self.users[sender].friends:
            return False, "Already friends"
        
        if receiver in self.users[sender].sent_requests:
            return False, "Request already sent"
        
        if sender in self.users[receiver].pending_requests:
            return False, "Request already pending"
        
        self.users[sender].sent_requests.append(receiver)
        self.users[receiver].pending_requests.append(sender)
        self.save_data()
        return True, "Friend request sent"
    
    def accept_friend_request(self, user, friend):
        """Accept friend request"""
        if friend not in self.users[user].pending_requests:
            return False, "No pending request from this user"
        
        self.users[user].pending_requests.remove(friend)
        self.users[friend].sent_requests.remove(user)
        
        self.users[user].friends.add(friend)
        self.users[friend].friends.add(user)
        self.adjacency_list[user].add(friend)
        self.adjacency_list[friend].add(user)
        
        self.save_data()
        return True, "Friend request accepted"
    
    def reject_friend_request(self, user, friend):
        """Reject friend request"""
        if friend not in self.users[user].pending_requests:
            return False, "No pending request from this user"
        
        self.users[user].pending_requests.remove(friend)
        self.users[friend].sent_requests.remove(user)
        self.save_data()
        return True, "Friend request rejected"
    
    def remove_friend(self, user, friend):
        """Remove friendship"""
        if friend not in self.users[user].friends:
            return False, "Not friends with this user"
        
        self.users[user].friends.remove(friend)
        self.users[friend].friends.remove(user)
        self.adjacency_list[user].discard(friend)
        self.adjacency_list[friend].discard(user)
        
        self.save_data()
        return True, "Friend removed"
    
    def get_mutual_friends(self, user1, user2):
        """Get mutual friends with details"""
        if user1 not in self.users or user2 not in self.users:
            return []
        
        friends1 = self.users[user1].friends
        friends2 = self.users[user2].friends
        mutual = friends1.intersection(friends2)
        
        # Return mutual friends with profile pictures
        return [{
            'username': username,
            'profile_pic': self.users[username].profile_pic
        } for username in mutual]
    
    def get_friend_suggestions(self, username, limit=10):
        """
        Enhanced: Get friend suggestions excluding users with pending requests
        """
        if username not in self.users:
            return []
        
        suggestions = {}
        user_friends = self.users[username].friends
        sent_requests = set(self.users[username].sent_requests)
        pending_requests = set(self.users[username].pending_requests)
        
        # BFS to find friends of friends
        for friend in user_friends:
            for fof in self.users[friend].friends:
                # Exclude: self, current friends, sent requests, pending requests
                if (fof != username and 
                    fof not in user_friends and 
                    fof not in sent_requests and 
                    fof not in pending_requests):
                    
                    mutual = self.get_mutual_friends(username, fof)
                    if fof not in suggestions:
                        suggestions[fof] = {
                            'username': fof,
                            'profile_pic': self.users[fof].profile_pic,
                            'mutual_count': len(mutual),
                            'mutual_friends': mutual
                        }
        
        # Sort by mutual friends count
        sorted_suggestions = sorted(
            suggestions.values(),
            key=lambda x: x['mutual_count'],
            reverse=True
        )
        
        return sorted_suggestions[:limit]
    
    def send_message(self, sender, receiver, content, message_type='text', image_path=None):
        """Send a message (text or image)"""
        if receiver not in self.users:
            return False, "User not found"
        
        if receiver not in self.users[sender].friends:
            return False, "Can only message friends"
        
        message = Message(sender, receiver, content, message_type, image_path)
        self.messages.append(message)
        
        # Index message for both sender and receiver
        self.message_index[sender].append(message.id)
        self.message_index[receiver].append(message.id)
        
        self.save_data()
        return True, "Message sent"
    
    def get_conversation(self, user1, user2):
        """Get all messages between two users"""
        conversation = []
        
        for message in self.messages:
            if ((message.sender == user1 and message.receiver == user2) or
                (message.sender == user2 and message.receiver == user1)):
                conversation.append(message.to_dict())
        
        # Sort by timestamp
        conversation.sort(key=lambda x: x['timestamp'])
        return conversation
    
    def get_unread_message_count(self, username):
        """Get count of unread messages for a user"""
        count = 0
        for message in self.messages:
            if message.receiver == username and not message.read:
                count += 1
        return count
    
    def mark_messages_read(self, user1, user2):
        """Mark all messages from user2 to user1 as read"""
        for message in self.messages:
            if message.sender == user2 and message.receiver == user1 and not message.read:
                message.read = True
        self.save_data()
    
    def search_users(self, query):
        """Search users by username"""
        if not query:
            return []
        
        query_lower = query.lower()
        results = []
        
        for username in self.users:
            if query_lower in username.lower():
                results.append({
                    'username': username,
                    'profile_pic': self.users[username].profile_pic
                })
        
        return sorted(results, key=lambda x: x['username'])
    
    def get_user_stats(self, username):
        """Get user statistics"""
        if username not in self.users:
            return None


        user = self.users[username]
        return {
            'username': username,
            'total_friends': len(user.friends),
            'pending_requests': len(user.pending_requests),
            'sent_requests': len(user.sent_requests),
            'profile_pic': user.profile_pic,
            'member_since': user.created_at,
            'bio': user.bio,
            'unread_messages': self.get_unread_message_count(username)
        }
    
    def save_data(self):
        """Persist data to JSON"""
        data = {
            'users': {username: user.to_dict() for username, user in self.users.items()},
            'messages': [msg.to_dict() for msg in self.messages]
        }
        
        with open('social_network_data.json', 'w') as f:
            json.dump(data, f, indent=2)
    
    def load_data(self):
        """Load data from JSON"""
        if os.path.exists('social_network_data.json'):
            try:
                with open('social_network_data.json', 'r') as f:
                    data = json.load(f)
                
                # Reconstruct users
                for username, user_data in data.get('users', {}).items():
                    self.users[username] = User.from_dict(user_data)
                    self.adjacency_list[username] = self.users[username].friends.copy()
                
                # Reconstruct messages
                for msg_data in data.get('messages', []):
                    message = Message.from_dict(msg_data)
                    self.messages.append(message)
                    self.message_index[message.sender].append(message.id)
                    self.message_index[message.receiver].append(message.id)


                return True
            except Exception as e:
                print(f"Error loading data: {e}")
                return False
        return False


# Initialize global network
network = SocialNetworkGraph()
network.load_data()


# ============================================================================
# FLASK ROUTES
# ============================================================================

@app.route('/')
def index():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        profile_pic_filename = 'default-avatar.png'
        
        if not username or not password:
            return jsonify({'success': False, 'message': 'All fields required'})
        
        if len(password) < 6:
            return jsonify({'success': False, 'message': 'Password must be at least 6 characters'})
        
        # Handle profile picture upload
        if 'profile_pic' in request.files:
            file = request.files['profile_pic']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"{username}_{uuid.uuid4().hex}.{file.filename.rsplit('.', 1)[1].lower()}")
                file.save(os.path.join(PROFILE_PICS_FOLDER, filename))
                profile_pic_filename = filename
        
        success, message = network.add_user(username, password, profile_pic_filename)
        return jsonify({'success': success, 'message': message})
    
    return render_template('signup.html')


@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '')
    
    if network.authenticate_user(username, password):
        session['username'] = username
        network.update_last_seen(username)
        return jsonify({'success': True, 'message': 'Login successful'})
    
    return jsonify({'success': False, 'message': 'Invalid credentials'})


@app.route('/logout')
def logout():
    if 'username' in session:
        network.update_last_seen(session['username'])
    session.pop('username', None)
    return redirect(url_for('index'))


@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('index'))
    
    return render_template('dashboard.html')


@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    """Serve uploaded files"""
    return send_from_directory(UPLOAD_FOLDER, filename)


@app.route('/api/user/stats')
def get_user_stats():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    stats = network.get_user_stats(session['username'])
    return jsonify(stats)


@app.route('/api/update-profile-picture', methods=['POST'])
def update_profile_picture():
    """Update user's profile picture"""
    if 'username' not in session:
        return jsonify({'success': False, 'message': 'Not authenticated'}), 401
    
    if 'profile_pic' not in request.files:
        return jsonify({'success': False, 'message': 'No file provided'})
    
    file = request.files['profile_pic']
    
    if file and file.filename and allowed_file(file.filename):
        username = session['username']
        filename = secure_filename(f"{username}_{uuid.uuid4().hex}.{file.filename.rsplit('.', 1)[1].lower()}")
        file_path = os.path.join(PROFILE_PICS_FOLDER, filename)
        file.save(file_path)
        
        success, message = network.update_profile_picture(username, filename)
        
        if success:
            return jsonify({
                'success': True,
                'message': 'Profile picture updated successfully',
                'profile_pic': filename
            })
    
    return jsonify({'success': False, 'message': 'Invalid file type'})


@app.route('/api/friends')
def get_friends():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    username = session['username']
    friends = []
    
    for friend_username in network.users[username].friends:
        friend = network.users[friend_username]
        unread = sum(1 for msg in network.messages 
                    if msg.sender == friend_username and msg.receiver == username and not msg.read)
        
        friends.append({
            'username': friend_username,
            'profile_pic': friend.profile_pic,
            'last_seen': friend.last_seen,
            'unread_count': unread
        })
    
    return jsonify(friends)


@app.route('/api/friend-requests')
def get_friend_requests():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    username = session['username']
    requests_data = []
    
    for requester in network.users[username].pending_requests:
        mutual = network.get_mutual_friends(username, requester)
        requests_data.append({
            'username': requester,
            'profile_pic': network.users[requester].profile_pic,
            'mutual_count': len(mutual),
            'mutual_friends': mutual
        })
    
    return jsonify(requests_data)


@app.route('/api/suggestions')
def get_suggestions():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    suggestions = network.get_friend_suggestions(session['username'])
    return jsonify(suggestions)


@app.route('/api/search')
def search():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    query = request.args.get('q', '')
    results = network.search_users(query)
    
    username = session['username']
    for result in results:
        user = result['username']
        if user == username:
            result['status'] = 'self'
        elif user in network.users[username].friends:
            result['status'] = 'friend'
        elif user in network.users[username].sent_requests:
            result['status'] = 'pending'
        else:
            result['status'] = 'none'
    
    return jsonify(results)


@app.route('/api/send-request', methods=['POST'])
def send_request():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    receiver = data.get('receiver')
    
    success, message = network.send_friend_request(session['username'], receiver)
    return jsonify({'success': success, 'message': message})


@app.route('/api/accept-request', methods=['POST'])
def accept_request():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    friend = data.get('friend')
    
    success, message = network.accept_friend_request(session['username'], friend)
    return jsonify({'success': success, 'message': message})


@app.route('/api/reject-request', methods=['POST'])
def reject_request():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    friend = data.get('friend')
    
    success, message = network.reject_friend_request(session['username'], friend)
    return jsonify({'success': success, 'message': message})


@app.route('/api/remove-friend', methods=['POST'])
def remove_friend():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.get_json()
    friend = data.get('friend')
    
    success, message = network.remove_friend(session['username'], friend)
    return jsonify({'success': success, 'message': message})


@app.route('/api/send-message', methods=['POST'])
def send_message():
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    receiver = request.form.get('receiver')
    content = request.form.get('content', '')
    message_type = 'text'
    image_path = None
    
    # Handle image upload
    if 'image' in request.files:
        file = request.files['image']
        if file and file.filename and allowed_file(file.filename):
            filename = secure_filename(f"msg_{uuid.uuid4().hex}.{file.filename.rsplit('.', 1)[1].lower()}")
            file.save(os.path.join(MESSAGE_IMAGES_FOLDER, filename))
            image_path = f"message_images/{filename}"
            message_type = 'image'
            if not content:
                content = "Sent an image"
    
    success, message = network.send_message(
        session['username'],
        receiver,
        content,
        message_type,
        image_path
    )
    
    return jsonify({'success': success, 'message': message})


@app.route('/api/conversation/<friend>')
def get_conversation(friend):
    if 'username' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    conversation = network.get_conversation(session['username'], friend)
    network.mark_messages_read(session['username'], friend)
    network.save_data()
    
    return jsonify(conversation)


if __name__ == '__main__':
    # Run on all interfaces to allow local network access
    app.run(debug=True, host='0.0.0.0', port=5000)